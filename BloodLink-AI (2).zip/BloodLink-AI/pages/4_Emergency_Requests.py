import streamlit as st
from sqlalchemy import text
from database.db import SessionLocal

st.title("🚨 Emergency Requests")

st.write("View all urgent organ requests.")

st.markdown("---")

db = SessionLocal()

try:
    requests = db.execute(
        text("""
            SELECT patient_name, age, blood_group,
                   organ, location, phone
            FROM organ_requests
            WHERE urgency = 'Emergency'
            ORDER BY id DESC
        """)
    ).fetchall()

    if requests:
        st.error(f"🚨 {len(requests)} Emergency Request(s)")

        for request in requests:
            st.markdown(
                f"""
                ---
                ### 🚨 {request.patient_name}

                **Age:** {request.age}  
                **Blood Group:** {request.blood_group}  
                **Required Organ:** {request.organ}  
                **Location:** 📍 {request.location}  
                **Contact:** {request.phone}
                """
            )

    else:
        st.success("No emergency requests currently.")

finally:
    db.close()