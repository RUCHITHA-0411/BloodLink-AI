import streamlit as st
from database.db import SessionLocal
from models.donor import Donor
from models.match import Match

st.title("⚙️ Admin Panel")

st.write("Manage BloodLink AI system information.")

st.markdown("---")

db = SessionLocal()

try:
    donor_count = db.query(Donor).count()
    match_count = db.query(Match).count()

finally:
    db.close()

col1, col2 = st.columns(2)

with col1:
    st.metric("🩸 Total Donors", donor_count)

with col2:
    st.metric("🤝 Total Matches", match_count)

st.markdown("---")

st.subheader("🛠️ System Information")

st.info(
    "BloodLink AI is a prototype system for donor search, "
    "organ requests and potential donor matching."
)

st.warning(
    "⚠️ This application is for demonstration purposes. "
    "Medical compatibility and final allocation decisions "
    "must be handled by qualified healthcare professionals."
)