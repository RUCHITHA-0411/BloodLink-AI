import streamlit as st
from database.db import SessionLocal
from models.match import Match

st.title("📋 Match History")

st.write("View all successfully confirmed donor matches.")

st.markdown("---")

db = SessionLocal()

try:
    matches = (
        db.query(Match)
        .order_by(Match.id.desc())
        .all()
    )

    if matches:

        st.success(f"Total Successful Matches: {len(matches)}")

        for match in matches:

            st.markdown("---")

            col1, col2 = st.columns(2)

            with col1:
                st.subheader(f"🩸 {match.donor_name}")
                st.write(f"**Patient:** {match.patient_name}")
                st.write(f"**Organ:** {match.organ}")
                st.write(f"**Blood Group:** {match.blood_group}")

            with col2:
                st.write(f"**Location:** 📍 {match.location}")
                st.write(f"**Match Score:** {match.score}/100")

                if match.score >= 80:
                    st.success("High Match")
                elif match.score >= 50:
                    st.info("Moderate Match")
                else:
                    st.warning("Low Match")

    else:
        st.info("No successful matches yet.")

finally:
    db.close()