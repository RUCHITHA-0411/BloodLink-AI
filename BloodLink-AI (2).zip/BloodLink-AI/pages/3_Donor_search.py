import streamlit as st
from database.db import SessionLocal
from models.donor import Donor

st.set_page_config(
    page_title="Donor Search",
    page_icon="🔎",
    layout="wide"
)

st.title("🔎 Donor Search")
st.write("Search available donors by blood group, organ and location.")

st.markdown("---")

col1, col2, col3 = st.columns(3)

with col1:
    blood_group = st.selectbox(
        "🩸 Blood Group",
        ["All", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
    )

with col2:
    organ = st.selectbox(
        "🫀 Organ",
        ["All", "Kidney", "Liver", "Heart", "Lung", "Pancreas"]
    )

with col3:
    location = st.text_input("📍 Location")

st.markdown("---")

if st.button("🔎 Search Donors", use_container_width=True):

    db = SessionLocal()

    try:
        query = db.query(Donor).filter(
            Donor.available == True
        )

        if blood_group != "All":
            query = query.filter(
                Donor.blood_group == blood_group
            )

        if organ != "All":
            query = query.filter(
                Donor.organ == organ
            )

        if location:
            query = query.filter(
                Donor.location.ilike(f"%{location}%")
            )

        donors = query.all()

        if donors:

            st.success(f"Found {len(donors)} available donor(s).")

            cols = st.columns(2)

            for i, donor in enumerate(donors):

                with cols[i % 2]:

                    st.markdown(
                        f"""
                        <div class="metric-card">
                            <h3>🩸 {donor.name}</h3>
                            <p><b>Blood Group:</b> {donor.blood_group}</p>
                            <p><b>Organ:</b> {donor.organ}</p>
                            <p><b>Age:</b> {donor.age}</p>
                            <p><b>Location:</b> 📍 {donor.location}</p>
                            <p>🟢 <b>Available</b></p>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )

        else:
            st.warning("No available donors found.")

    finally:
        db.close()