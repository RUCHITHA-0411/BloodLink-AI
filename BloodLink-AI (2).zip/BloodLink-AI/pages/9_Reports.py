import streamlit as st
import pandas as pd
from database.db import SessionLocal
from models.donor import Donor
from models.match import Match
from sqlalchemy import text

st.title("📥 Reports")

st.write("Generate and download BloodLink AI reports.")

st.markdown("---")

db = SessionLocal()

try:
    donors = db.query(Donor).all()
    matches = db.query(Match).all()

    requests = db.execute(
        text("""
            SELECT patient_name, age, blood_group,
                   organ, location, urgency
            FROM organ_requests
        """)
    ).fetchall()

finally:
    db.close()


st.subheader("🩸 Donor Report")

if donors:
    donor_data = [
        {
            "Name": d.name,
            "Age": d.age,
            "Blood Group": d.blood_group,
            "Organ": d.organ,
            "Location": d.location,
            "Available": "Yes" if d.available else "No"
        }
        for d in donors
    ]

    donor_df = pd.DataFrame(donor_data)

    st.dataframe(
        donor_df,
        use_container_width=True
    )

    st.download_button(
        "📥 Download Donor Report",
        donor_df.to_csv(index=False),
        "donor_report.csv",
        "text/csv"
    )

else:
    st.info("No donor data available.")


st.markdown("---")

st.subheader("🏥 Organ Request Report")

if requests:
    request_data = [
        {
            "Patient": r.patient_name,
            "Age": r.age,
            "Blood Group": r.blood_group,
            "Organ": r.organ,
            "Location": r.location,
            "Urgency": r.urgency
        }
        for r in requests
    ]

    request_df = pd.DataFrame(request_data)

    st.dataframe(
        request_df,
        use_container_width=True
    )

    st.download_button(
        "📥 Download Request Report",
        request_df.to_csv(index=False),
        "organ_request_report.csv",
        "text/csv"
    )

else:
    st.info("No organ request data available.")


st.markdown("---")

st.subheader("🤝 Match Report")

if matches:
    match_data = [
        {
            "Donor": m.donor_name,
            "Patient": m.patient_name,
            "Organ": m.organ,
            "Blood Group": m.blood_group,
            "Location": m.location,
            "Score": m.score
        }
        for m in matches
    ]

    match_df = pd.DataFrame(match_data)

    st.dataframe(
        match_df,
        use_container_width=True
    )

    st.download_button(
        "📥 Download Match Report",
        match_df.to_csv(index=False),
        "match_report.csv",
        "text/csv"
    )

else:
    st.info("No successful matches available.")