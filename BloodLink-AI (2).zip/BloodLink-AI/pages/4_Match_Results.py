import streamlit as st

from database.db import SessionLocal
from models.donor import Donor
from models.match import Match
from services.matching import find_matches


st.title("🤝 Match Results")

st.write(
    "Find potential donor matches based on the selected "
    "organ, blood group, and location."
)

st.markdown("---")


# Get available donors
db = SessionLocal()

try:
    donors = db.query(Donor).filter(Donor.available == True).all()
finally:
    db.close()


if not donors:

    st.warning("No available donors are registered yet.")

else:

    st.subheader("🔎 Search for Potential Matches")

    organ = st.selectbox(
        "Required Organ",
        [
            "Kidney",
            "Liver",
            "Heart",
            "Lung",
            "Pancreas"
        ]
    )

    blood_group = st.selectbox(
        "Patient Blood Group",
        [
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"
        ]
    )

    location = st.text_input("Patient Location")

    if st.button("🔎 Find Potential Matches"):

        class Request:
            pass

        request = Request()

        request.organ = organ
        request.blood_group = blood_group
        request.location = location

        matches = find_matches(
            donors,
            request
        )

        if matches:

            st.success(
                f"Found {len(matches)} potential match(es)."
            )

            st.markdown("---")

            for match in matches:

                donor = match["donor"]
                score = match["score"]

                st.subheader(
                    f"🩸 {donor.name}"
                )

                col1, col2 = st.columns(2)

                with col1:

                    st.write(
                        f"**Blood Group:** "
                        f"{donor.blood_group}"
                    )

                    st.write(
                        f"**Organ:** "
                        f"{donor.organ}"
                    )

                    st.write(
                        f"**Location:** "
                        f"{donor.location}"
                    )

                with col2:

                    st.write(
                        f"**Match Score:** "
                        f"{score}/100"
                    )

                    if score >= 80:

                        st.success(
                            "High potential match"
                        )

                    elif score >= 50:

                        st.info(
                            "Moderate potential match"
                        )

                    else:

                        st.warning(
                            "Low potential match"
                        )

                # Confirm successful match
                if st.button(
                    f"✅ Confirm Match with {donor.name}",
                    key=f"confirm_{donor.id}"
                ):

                    db = SessionLocal()

                    try:

                        successful_match = Match(
                            donor_name=donor.name,
                            patient_name="Test Patient",
                            organ=donor.organ,
                            blood_group=donor.blood_group,
                            location=donor.location,
                            score=score
                        )

                        db.add(successful_match)
                        db.commit()

                        st.success(
                            f"✅ Match with {donor.name} "
                            f"confirmed successfully!"
                        )

                    except Exception as e:

                        db.rollback()

                        st.error(
                            f"Error saving match: {e}"
                        )

                    finally:

                        db.close()

                st.markdown("---")

            st.info(
                "⚕️ These are potential matches only. "
                "Final compatibility and allocation decisions "
                "must be made by qualified healthcare "
                "professionals and authorized authorities."
            )

        else:

            st.warning(
                "No potential matches found."
            )