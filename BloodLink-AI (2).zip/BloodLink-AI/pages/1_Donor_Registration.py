import streamlit as st

from database.db import Base, SessionLocal, engine
from models.donor import Donor

# Create database tables
Base.metadata.create_all(bind=engine)

st.title("🩸 Donor Registration")
st.write("Register donor information for the BloodLink AI system.")

st.markdown("---")

with st.form("donor_registration_form"):

    name = st.text_input("Full Name")

    col1, col2 = st.columns(2)

    with col1:
        age = st.number_input(
            "Age",
            min_value=18,
            max_value=100,
            value=18,
            step=1
        )

    with col2:
        blood_group = st.selectbox(
            "Blood Group",
            [
                "A+",
                "A-",
                "B+",
                "B-",
                "AB+",
                "AB-",
                "O+",
                "O-"
            ]
        )

    organ = st.selectbox(
        "Organ Willing to Donate",
        [
            "Kidney",
            "Liver",
            "Heart",
            "Lung",
            "Pancreas"
        ]
    )

    location = st.text_input(
        "City / Location",
        placeholder="Example: Hyderabad"
    )

    phone = st.text_input(
        "Contact Number",
        placeholder="Enter contact number"
    )

    available = st.checkbox(
        "Currently available for contact",
        value=True
    )

    consent = st.checkbox(
        "I confirm that the information entered is accurate."
    )

    submitted = st.form_submit_button(
        "Register Donor",
        use_container_width=True
    )

    if submitted:

        if not name.strip():
            st.error("Please enter the donor name.")

        elif age < 18:
            st.error("Age must be 18 or above.")

        elif not location.strip():
            st.error("Please enter the location.")

        elif not phone.strip():
            st.error("Please enter the contact number.")

        elif not consent:
            st.error("Please confirm the information before registering.")

        else:
            db = SessionLocal()

            try:
                donor = Donor(
                    name=name.strip(),
                    age=age,
                    blood_group=blood_group,
                    organ=organ,
                    location=location.strip(),
                    phone=phone.strip(),
                    available=available
                )

                db.add(donor)
                db.commit()

                st.success(
                    "✅ Donor registered successfully!"
                )

            except Exception as e:
                db.rollback()
                st.error(f"Registration failed: {e}")

            finally:
                db.close()