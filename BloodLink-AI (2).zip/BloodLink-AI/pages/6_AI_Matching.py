import streamlit as st

from database.db import SessionLocal
from models.donor import Donor
from services.matching import find_matches

st.title("🤖 AI Donor Matching")

st.write(
    "Find available donors that match an organ request."
)

st.markdown("---")

db = SessionLocal()

try:
    donors = db.query(Donor).filter(Donor.available == True).all()

    if not donors:
        st.warning("No available donors are registered yet.")
        st.info(
            "Please register a donor first, then return to AI Matching."
        )
    else:
        st.subheader("Available Donors")

        for donor in donors:
            st.write(
                f"🩸 **{donor.name}** | "
                f"Organ: {donor.organ} | "
                f"Blood Group: {donor.blood_group} | "
                f"Location: {donor.location}"
            )

        st.markdown("---")

        st.subheader("Select Organ Requirement")

        organ = st.selectbox(
            "Required Organ",
            ["Kidney", "Liver", "Heart", "Lung", "Pancreas"]
        )

        blood_group = st.selectbox(
            "Patient Blood Group",
            ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
        )

        location = st.text_input("Patient Location")

        if st.button("🔎 Find Matches"):

            class Request:
                pass

            request = Request()
            request.organ = organ
            request.blood_group = blood_group
            request.location = location

            matches = find_matches(donors, request)

            if matches:
                st.success(
                    f"Found {len(matches)} potential donor match(es)."
                )

                for match in matches:
                    donor = match["donor"]
                    score = match["score"]

                    st.markdown("---")
                    st.write(f"### 🩸 {donor.name}")
                    st.write(f"**Match Score:** {score}/100")
                    st.write(f"**Blood Group:** {donor.blood_group}")
                    st.write(f"**Organ:** {donor.organ}")
                    st.write(f"**Location:** {donor.location}")

            else:
                st.warning(
                    "No potential matches found for the selected criteria."
                )

finally:
    db.close()