import streamlit as st
from sqlalchemy import text
from database.db import SessionLocal
from models.donor import Donor
from models.match import Match

st.title("📊 Analytics")

st.write("BloodLink AI system statistics and analytics.")

st.markdown("---")

db = SessionLocal()

try:
    donors = db.query(Donor).count()
    matches = db.query(Match).count()

    requests = db.execute(
        text("SELECT COUNT(*) FROM organ_requests")
    ).scalar()

    emergency = db.execute(
        text("""
            SELECT COUNT(*)
            FROM organ_requests
            WHERE urgency = 'Emergency'
        """)
    ).scalar()

finally:
    db.close()

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("🩸 Donors", donors)

with col2:
    st.metric("🏥 Requests", requests)

with col3:
    st.metric("🤝 Matches", matches)

with col4:
    st.metric("🚨 Emergency", emergency)

st.markdown("---")

st.subheader("📈 System Overview")

chart_data = {
    "Category": [
        "Donors",
        "Requests",
        "Matches",
        "Emergency"
    ],
    "Count": [
        donors,
        requests,
        matches,
        emergency
    ]
}

st.bar_chart(
    chart_data,
    x="Category",
    y="Count"
)