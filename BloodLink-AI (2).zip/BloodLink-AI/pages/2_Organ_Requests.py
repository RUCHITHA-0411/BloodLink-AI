import streamlit as st
from sqlalchemy import Column, Integer, String
from database.db import Base, SessionLocal


class OrganRequest(Base):
    __tablename__ = "organ_requests"
    __table_args__={"extend_existing":True}

    id = Column(Integer, primary_key=True, index=True)
    patient_name = Column(String(100), nullable=False)
    age = Column(Integer, nullable=False)
    blood_group = Column(String(10), nullable=False)
    organ = Column(String(50), nullable=False)
    location = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=False)
    urgency = Column(String(20), nullable=False)


# Create the table
Base.metadata.create_all(bind=__import__("database.db", fromlist=["engine"]).engine)


st.title("🏥 Organ Request")

st.write(
    "Register a patient who needs an organ. "
    "Please use test information while developing the prototype."
)

st.markdown("---")

with st.form("organ_request_form"):

    patient_name = st.text_input("Patient Name")

    age = st.number_input(
        "Patient Age",
        min_value=1,
        max_value=120,
        value=18
    )

    blood_group = st.selectbox(
        "Blood Group",
        ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
    )

    organ = st.selectbox(
        "Required Organ",
        ["Kidney", "Liver", "Heart", "Lung", "Pancreas"]
    )

    location = st.text_input("Location")

    phone = st.text_input("Contact Number")

    urgency = st.selectbox(
        "Urgency",
        ["Normal", "Urgent", "Emergency"]
    )

    submitted = st.form_submit_button("Submit Organ Request")

    if submitted:

        if not patient_name or not location or not phone:
            st.error("Please fill in all required fields.")

        else:
            db = SessionLocal()

            try:
                request = OrganRequest(
                    patient_name=patient_name,
                    age=age,
                    blood_group=blood_group,
                    organ=organ,
                    location=location,
                    phone=phone,
                    urgency=urgency
                )

                db.add(request)
                db.commit()

                st.success("✅ Organ request registered successfully!")

            except Exception as e:
                db.rollback()
                st.error(f"Error saving request: {e}")

            finally:
                db.close()
