def find_matches(donors, request):
    matches = []

    for donor in donors:
        score = 0

        # Organ must match
        if donor.organ.lower() != request.organ.lower():
            continue

        # Blood group match
        if donor.blood_group == request.blood_group:
            score += 50

        # Location match
        if donor.location.lower() == request.location.lower():
            score += 30

        # Available donor
        if donor.available:
            score += 20
        else:
            continue

        matches.append({
            "donor": donor,
            "score": score
        })

    matches.sort(
        key=lambda item: item["score"],
        reverse=True
    )

    return matches