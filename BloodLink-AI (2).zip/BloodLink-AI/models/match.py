from sqlalchemy import Column, Integer, String
from database.db import Base


class Match(Base):
    __tablename__ = "matches"

    id = Column(Integer, primary_key=True, index=True)

    donor_name = Column(String(100), nullable=False)
    patient_name = Column(String(100), nullable=False)

    organ = Column(String(50), nullable=False)
    blood_group = Column(String(10), nullable=False)
    location = Column(String(100), nullable=False)

    score = Column(Integer, nullable=False)