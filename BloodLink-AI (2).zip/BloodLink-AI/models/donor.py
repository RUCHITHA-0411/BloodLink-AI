from sqlalchemy import Column, Integer, String, Boolean
from database.db import Base


class Donor(Base):
    __tablename__ = "donors"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    age = Column(Integer, nullable=False)
    blood_group = Column(String(10), nullable=False)
    organ = Column(String(50), nullable=False)
    location = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=False)
    available = Column(Boolean, default=True)