import streamlit as st

from database.db import Base, engine, SessionLocal
from models.donor import Donor
from models.match import Match
from sqlalchemy import inspect, text
st.markdown("""
<style>

[data-testid="stSidebar"] {
    background-color: #eef3fb;
}

[data-testid="stSidebarNav"] {
    display: none;
}

[data-testid="stSidebar"] h1 {
    color: #d81b60;
}

.metric-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
}

</style>
""", unsafe_allow_html=True)

# Create database tables
Base.metadata.create_all(bind=engine)


# Page configuration
st.set_page_config(
    page_title="BloodLink AI",
    page_icon="🩸",
    layout="wide"
)


# -----------------------------
# Database statistics
# -----------------------------

db = SessionLocal()
try:
    successful_matches = db.query(Match).count()
finally:
    db.close()

try:
    registered_donors = db.query(Donor).count()
    db = SessionLocal()



    # Check whether organ_requests table exists
    inspector = inspect(engine)
    tables = inspector.get_table_names()

    if "organ_requests" in tables:

        active_requests = db.execute(
            text("SELECT COUNT(*) FROM organ_requests")
        ).scalar()

        emergency_cases = db.execute(
            text(
                "SELECT COUNT(*) FROM organ_requests "
                "WHERE urgency = 'Emergency'"
            )
        ).scalar()

    else:
        active_requests = 0
        emergency_cases = 0

finally:
    db.close()


# -----------------------------
# Sidebar
# -----------------------------
# Branding
st.sidebar.markdown(
    """
    <div style="text-align:center; margin-bottom:80px;">
        <h1>🩸 BloodLink AI</h1>
        <p>Smart Organ Matching System</p>
    </div>
    """,
    unsafe_allow_html=True
)

# ================= NAVIGATION =================

st.sidebar.page_link(
    "app.py",
    label="🏠 Dashboard"
)

st.sidebar.page_link(
    "pages/1_Donor_Registration.py",
    label="🩸 Donor Registration"
)

st.sidebar.page_link(
    "pages/3_Donor_search.py",
    label="🔎 Donor Search"
)

st.sidebar.page_link(
    "pages/2_Organ_Requests.py",
    label="🏥 Organ Requests"
)

st.sidebar.page_link(
    "pages/4_Emergency_Requests.py",
    label="🚨 Emergency Requests"
)

st.sidebar.page_link(
    "pages/6_AI_Matching.py",
    label="🤖 AI Matching"
)

st.sidebar.page_link(
    "pages/4_Match_Results.py",
    label="🤝 Match Results"
)

st.sidebar.page_link(
    "pages/7_Match_History.py",
    label="📋 Match History"
)

st.sidebar.page_link(
    "pages/8_Analytics.py",
    label="📊 Analytics"
)

st.sidebar.page_link(
    "pages/9_Reports.py",
    label="📥 Reports"
)

st.sidebar.page_link(
    "pages/10_Admin.py",
    label="⚙️ Admin"
)
# -----------------------------
# Main Dashboard
# -----------------------------
st.markdown(
    '<div class="main-title">🩸 BloodLink AI</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'Intelligent Organ Donor Matching & Emergency Assistance System'
    '</div>',
    unsafe_allow_html=True
)

st.markdown("---")

# -----------------------------
# Dashboard Metrics
# -----------------------------

col1, col2, col3, col4 = st.columns(4)
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(
        f"""
        <div class="metric-card">
            <div>🩸 Registered Donors</div>
            <h2>{registered_donors}</h2>
        </div>
        """,
        unsafe_allow_html=True
    )

with col2:
    st.markdown(
        f"""
        <div class="metric-card">
            <div>🏥 Active Requests</div>
            <h2>{active_requests}</h2>
        </div>
        """,
        unsafe_allow_html=True
    )

with col3:
    st.markdown(
        f"""
        <div class="metric-card">
            <div>🤝 Successful Matches</div>
            <h2>{successful_matches}</h2>
        </div>
        """,
        unsafe_allow_html=True
    )

with col4:
    st.markdown(
        f"""
        <div class="metric-card">
            <div>🚨 Emergency Cases</div>
            <h2>{emergency_cases}</h2>
        </div>
        """,
        unsafe_allow_html=True
    )

st.markdown("---")
st.header("🩸 Recent Donors")

db = SessionLocal()

try:
    recent_donors = (
        db.query(Donor)
        .order_by(Donor.id.desc())
        .limit(5)
        .all()
    )

    if recent_donors:
        for donor in recent_donors:
            st.markdown(
                f"""
                <div class="metric-card">
                    🩸 <b>{donor.name}</b>
                    &nbsp; | &nbsp; {donor.blood_group}
                    &nbsp; | &nbsp; {donor.organ}
                    &nbsp; | &nbsp; 📍 {donor.location}
                </div>
                """,
                unsafe_allow_html=True
            )
    else:
        st.info("No donors registered yet.")

finally:
    db.close()
    st.markdown("---")

st.header("🏥 Recent Organ Requests")

db = SessionLocal()

try:
    inspector = inspect(engine)

    if "organ_requests" in inspector.get_table_names():

        recent_requests = db.execute(
            text("""
                SELECT patient_name, blood_group, organ,
                       location, urgency
                FROM organ_requests
                ORDER BY id DESC
                LIMIT 5
            """)
        ).fetchall()

        if recent_requests:
            for request in recent_requests:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        🏥 <b>{request.patient_name}</b>
                        &nbsp; | &nbsp; {request.blood_group}
                        &nbsp; | &nbsp; {request.organ}
                        &nbsp; | &nbsp; 📍 {request.location}
                        &nbsp; | &nbsp; 🚨 {request.urgency}
                    </div>
                    """,
                    unsafe_allow_html=True
                )
        else:
            st.info("No organ requests yet.")

finally:
    db.close()
    st.markdown("---")

st.header("⚡ Quick Actions")

col1, col2, col3 = st.columns(3)

with col1:
    st.info("🩸 **Donor Registration**\n\nRegister a new donor.")

with col2:
    st.info("🏥 **Organ Request**\n\nCreate a patient request.")

with col3:
    st.info("🤖 **AI Matching**\n\nFind potential donor matches.")
    st.markdown("---")

st.header("📊 System Overview")

chart_data = {
    "Category": [
        "Donors",
        "Organ Requests",
        "Successful Matches",
        "Emergency Cases"
    ],
    "Count": [
        registered_donors,
        active_requests,
        successful_matches,
        emergency_cases
    ]
}

st.bar_chart(
    chart_data,
    x="Category",
    y="Count"
)